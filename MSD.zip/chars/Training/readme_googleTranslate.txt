Tentatively completed!

�� Character overview
Together with the name

-------------------------------------------------------------------------------------------- -------------------------------------------------------------------- -------
�� What's this?
To accompany training and character creation! It is!

-------------------------------------------------------------------------------------------- -------------------------------------------------------------------- -------
�� feeling
Great convenience! It is! right?

-------------------------------------------------------------------------------------------- -------------------------------------------------------------------- -------
�� How to operate
Normal technique
A Check head position
B Check mid-position
C We will distance the attack. Please attack if you bow.
A by frame advance, and judgment is again made by C once an attack judgment comes out. You can cancel with B
You can also set the attack range by pressing the X button when an attack judgment comes out during frame advance
X Attack attack. Please confirm to the address such as the aerial, three patterns of flexion
4X haste jumping tool. Projectile type
6X haste jumping tool. Helper type
Y Display training parameters. Every time you press it, it changes whether it is back or front
Z Display the grid so that you can measure the distance. Every time you press it, it changes whether it is back or front
Open Start option

�E Optional item
STATE TYPE You can set the action while waiting S: normal C: bend A: jump
DISTANCE Distance can be set 4 patterns
AUTO GUARD Set whether to guard with auto, 1HIT guards after 2Hit (for combo check), ADV. Will do the advertisement
RECOVER You can also set whether to take passive or down avoidance
RECOVER TIME You can set how many frames you will pass after you become passive. Change by 10, a, b
POINTER TYPE You can set a pointer to display the distance to the other party
LIEDOWN TIME You can set how many frames to wake up after down. Change by 10, a, b
GET UP TYPE Setting whether to move up or not
�E Display parameter (It is not this character but the criteria of other character)
DAMAGE Damage caused by that attack
TOTAL DAMEGE Damage caused by that combo
Record high score of MAX DAMAGE TOTAL DAMAGE
MAX COMBO record high scores for number of combos
ADV. FRAME Displays the advantageous frame of attack given last (in case of disadvantage - is appended)
ENEMY CTRL Displays whether the enemy is currently controllable

�EInitial setting
It can be changed from config.txt

�E Special specifications
It will not die in VS mode
LIFE will be fully recovered by waiting for a fixed time state 0

�E Change size
Changing characters is possible for those who wish other than Kungfu Man size
�E Small size Prinny (Disgaea series)
�E Medium size ratio Nanae Izumi Ten (Toho Project)
�E Large size Hugo (Street Fighter III series)
Please copy all the files in the small, medium, large folders and paste them in the Training folder
If you want to restore it, copy all the files in the kfm folder and paste it in the Training folder.
-------------------------------------------------------------------------------------------- -------------------------------------------------------------------- -------
�� a bit of note
Because explods are used in large quantities, it is strict that ExplodMax is the default
Try setting the ExplodMax value of mugen.cfg to around 200

Damage related indication is judged by reduced life
For this reason, it becomes impossible to judge exactly when the remaining life becomes small
If you are interested in Kore please make initial LIFE like 100000
-------------------------------------------------------------------------------------------- -------------------------------------------------------------------- -------
�� Special thanks
Everyone who talks about mugen
I am asked to use Mr. kong's effect of Adoga
I am referring to the description of Mr. Guard
-------------------------------------------------------------------------------------------- -------------------------------------------------------------------- -------
�� Update contents
09.11.25 tentatively open to the public
09.11.26 Change font
To appearance to Kung Fu Man
Option items Various additions
09.11.29 Add pointer and various others
09.12.01 Added flexibility display, can change time down
09.12.06 Adga, down avoidance, move upward addition added
09.12.10 small, medium Add folder
09.12.15 large Addition of folders, other details
09.12.16 Bug fix for guard knockback
-------------------------------------------------------------------------------------------- -------------------------------------------------------------------- -------
�� Future plans
Absent! I will add it if there is any demand.

-------------------------------------------------------------------------------------------- -------------------------------------------------------------------- -------

Unauthorized reprint, unauthorized modification, unauthorized disclosure is at your own risk.
I do not complain from me even if I do not take permission etc for using this character at all.
If you have any request, please send it by e-mail or e-mail.
By stupa

-------------------------------------------------------------------------------------------- -------------------------------------------------------------------- -------
In the case of
Self site http://www.yakibuta-reimen2.com/
Contact address yakibuta_reimen@yahoo.co.jp